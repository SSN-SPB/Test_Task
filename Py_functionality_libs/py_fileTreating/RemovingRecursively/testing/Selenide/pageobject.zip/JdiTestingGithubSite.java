package io.github.jditesting;
	
import io.github.jditesting.pages.*;
import com.epam.jdi.uitests.web.selenium.elements.composite.WebSite;
import com.epam.jdi.uitests.web.selenium.elements.pageobjects.annotations.*;

@JSite("https://jdi-testing.github.io")
public class JdiTestingGithubSite extends WebSite {
    @JPage(url = "/jdi-light/index.html", title = "Home Page") 
    public static HomePage homePage;
 	
}