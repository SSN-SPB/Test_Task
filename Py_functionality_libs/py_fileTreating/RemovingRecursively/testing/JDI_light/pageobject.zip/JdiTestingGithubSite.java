package io.github.jditesting;
	
import com.epam.jdi.light.elements.pageobjects.annotations.*;
import io.github.jditesting.pages.*;

@JSite("https://jdi-testing.github.io")
public class JdiTestingGithubSite {
    @Url("/jdi-light/index.html") @Title("Home Page") 
    public static HomePage homePage;
 	
}