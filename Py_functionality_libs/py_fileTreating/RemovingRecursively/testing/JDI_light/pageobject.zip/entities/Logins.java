package io.github.jditesting.entities;

import com.epam.jdi.tools.DataClass;

public class Logins extends DataClass<Logins> {
    public String name;
    public String password;
}