package io.github.jditesting.sections;

import com.epam.jdi.uitests.web.selenium.elements.common.*;
import com.epam.jdi.uitests.web.selenium.elements.complex.*;
import com.epam.jdi.uitests.web.selenium.elements.composite.*;
import com.epam.jdi.uitests.web.selenium.elements.composite.WebPage;
import com.epam.jdi.uitests.web.selenium.elements.pageobjects.annotations.objects.*;
import com.epam.jdi.uitests.web.selenium.elements.pageobjects.annotations.simple.*;
import com.epam.jdi.uitests.web.selenium.elements.pageobjects.annotations.FindBy;

public class Header extends Section {
    @Css("form") public LoginForm loginForm;
    @XPath(".//button[@type='submit']") public Button logout;
    @Css("#epam-logo") public Image epamLogo;
    @Css("#user-icon") public Image userIcon;
    @Css("input[type=text]") public TextField textField412441;
	
}