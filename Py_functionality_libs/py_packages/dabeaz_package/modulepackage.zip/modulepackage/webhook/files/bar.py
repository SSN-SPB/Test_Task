# bar.py

print('imported bar')
