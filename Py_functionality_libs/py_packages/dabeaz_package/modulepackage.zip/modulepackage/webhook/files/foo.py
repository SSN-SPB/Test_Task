# foo.py

print('imported foo')
