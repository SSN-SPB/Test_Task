# script.py

print("I'm a script")
