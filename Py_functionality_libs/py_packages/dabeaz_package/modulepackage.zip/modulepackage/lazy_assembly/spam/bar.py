# bar.py

__all__ = ['Bar']

class Bar(object):
    pass

print('bar imported')
