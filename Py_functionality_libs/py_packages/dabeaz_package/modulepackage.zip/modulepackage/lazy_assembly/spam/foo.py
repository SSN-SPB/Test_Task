# foo.py

__all__ = ['Foo']

class Foo(object):
    pass

print('foo imported')
