# spam.py

try:
    import foo
except ImportError:
    import simplefoo as foo

