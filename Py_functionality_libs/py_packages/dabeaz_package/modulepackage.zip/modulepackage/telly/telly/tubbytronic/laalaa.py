# laalaa.py

print('imported laalaa')
