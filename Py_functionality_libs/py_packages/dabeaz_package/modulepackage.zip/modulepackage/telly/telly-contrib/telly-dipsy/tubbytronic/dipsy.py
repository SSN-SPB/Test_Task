# dipsy.py

print('imported dipsy')
