# Tests namespace subpackage

import telly.tubbytronic
print(telly.tubbytronic.__path__)

import telly.tubbytronic.laalaa
import telly.tubbytronic.po
import telly.tubbytronic.dipsy

