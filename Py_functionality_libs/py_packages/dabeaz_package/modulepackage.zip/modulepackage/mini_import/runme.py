from mini_imp import import_module

spam = import_module('spam')
spam.foo()
spam.bar()
