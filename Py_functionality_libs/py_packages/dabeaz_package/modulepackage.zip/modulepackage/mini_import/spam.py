# spam.py

print('imported spam')

def foo():
    print('spam.foo')

def bar():
    print('spam.bar')

