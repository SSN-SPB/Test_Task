# simplefoo.py

print('imported simplefoo')
