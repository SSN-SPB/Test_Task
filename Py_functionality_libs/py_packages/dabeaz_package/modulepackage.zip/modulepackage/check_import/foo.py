# foo.py
import bar

print('imported foo')
