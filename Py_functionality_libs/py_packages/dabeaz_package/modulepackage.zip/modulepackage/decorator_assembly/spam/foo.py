# foo.py

from . import export

@export
class Foo(object):
    pass

print('foo imported')
