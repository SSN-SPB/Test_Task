# bar.py

from . import export

@export
class Bar(object):
    pass

print('bar imported')
