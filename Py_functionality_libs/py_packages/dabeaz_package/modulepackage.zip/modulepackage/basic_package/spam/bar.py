# bar.py

class Bar(object):
    pass

print('bar imported')
