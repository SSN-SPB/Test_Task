# foo.py

class Foo(object):
    pass

print('foo imported')
