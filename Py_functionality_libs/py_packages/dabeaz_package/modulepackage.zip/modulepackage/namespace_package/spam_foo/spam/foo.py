# foo.py

class Foo(object):
    pass

print('imported foo')
