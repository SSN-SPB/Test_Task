# bar.py

class Bar(object):
    pass

print('imported bar')
