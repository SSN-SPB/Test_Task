This is a simple example package. You can use
[Github-flavored Markdown](https://github.com/SSN-SPB/)
to write your content.
