# substring_package


A test Python package that provides substring functions.


## Installation
pip install substring_package


## Usage
```python
from substring_package import substring_by_index
print(substring_by_index("a1b2c3d4e5", 3))


## Package creating
1 pip install --upgrade build twine

Remark:
build → creates distribution files
twine → uploads them to PyPI)

2 after that 
python -m build
The command creates
dist/
├── coolmath-0.1.0.tar.gz
└── coolmath-0.1.0-py3-none-any.whl

Now upload 
twine upload --repository testpypi dist/*


Upload to TestPyPI 
Upload to TestPyPI first (VERY recommended)
twine upload --repository testpypi dist/*

Log in when prompted.

Then test install it:

pip install --index-url https://test.pypi.org/simple/ coolmath


7 Colleague installs it like this:
pip install yourpkg-0.1.0-py3-none-any.whl